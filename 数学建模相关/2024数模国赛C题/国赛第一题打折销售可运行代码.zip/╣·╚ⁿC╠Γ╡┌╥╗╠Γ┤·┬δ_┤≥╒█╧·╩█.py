import pandas as pd
from pulp import LpMaximize, LpProblem, LpVariable, lpSum, PULP_CBC_CMD, LpStatus
from openpyxl import load_workbook

# 读取地块、作物和销量数据
land_data = pd.read_excel('地.xlsx')
crop_data = pd.read_csv('地菜.csv')
sales_data = pd.read_csv('菜的销量数据.csv')
ans = pd.read_excel('result.xlsx')

# 将预期销量数据合并到作物数据中
crop_data = crop_data.merge(sales_data[['作物编号', '预期销量','作物类型']], left_on='作物编号', right_on='作物编号', how='left')

# 将种植季次为"单季"的作物修改为"第一季"
crop_data['种植季次'] = crop_data['种植季次'].replace('单季', '第一季')

# 创建优化模型
model = LpProblem("Maximize_Crop_Profit", LpMaximize)

# 决策变量定义
A = {}  # A_{i,t,k,s}，种植面积变量
x = {}  # x_{i,t,k,s}，01决策变量
actual_sales = {}  # 实际销售量
discount_sales = {}  # 降价销售量

years = range(2024, 2031)  # 时间索引t从2024到2030
seasons = [1, 2]  # 季次索引s，1和2
crops = crop_data.index  # 作物索引i
lands = land_data.index  # 地块索引k

# 创建决策变量
for i in crops:
    for t in years:
        for k in lands:
            for s in seasons:
                A[(i, t, k, s)] = LpVariable(f"A_{i}_{t}_{k}_{s}", lowBound=0)  # 种植面积
                x[(i, t, k, s)] = LpVariable(f"x_{i}_{t}_{k}_{s}", lowBound=0, cat='Binary')  # 01决策变量

# 构建目标函数

for i in crops:
    for t in years:
        actual_sales[(i, t)] = LpVariable(f"actual_sales_{i}_{t}", lowBound=0)  # 实际销售量变量
        discount_sales[(i, t)] = LpVariable(f"discount_sales_{i}_{t}", lowBound=0)  # 降价销售量变量

revenue_normal = lpSum([
    actual_sales[(i, t)] * crop_data.loc[i, '销售单价/(元/斤)']
    for i in crops for t in years
])

revenue_discount = lpSum([
    discount_sales[(i, t)] * 0.5 * crop_data.loc[i, '销售单价/(元/斤)']
    for i in crops for t in years
])

total_cost = lpSum([
    A[(i, t, k, s)] * crop_data.loc[i, '种植成本/(元/亩)']
    for i in crops for t in years for k in lands for s in seasons
])

for i in crops: # 实际销售量和降价销售量的关系约束(无法直接使用min_max)
    for t in years:
        total_production = lpSum(A[(i, t, k, s)] * crop_data.loc[i, '亩产量/斤'] for k in lands for s in seasons)
        model += actual_sales[(i, t)] <= crop_data.loc[i, '预期销量'], f"MaxActualSales_{i}_{t}"
        model += actual_sales[(i, t)] + discount_sales[(i, t)] == total_production, f"SalesDistribution_{i}_{t}"

model += revenue_normal + revenue_discount - total_cost, "Objective"


# 添加约束条件

# 确保A和x之间的关系成立，且被选择的作物不能小于相应地块面积的1/3
for t in years:
    for k in lands:
        max_area = land_data.loc[k, '种植面积/亩']
        for i in crops:
            for s in seasons:
                model += A[(i, t, k, s)] <= max_area * x[(i, t, k, s)], f"Area_Binary_Link_{i}_{t}_{k}_{s}"
                model += A[(i, t, k, s)] >= max_area * x[(i, t, k, s)] / 4, f"Area_MinArea_Link_{i}_{t}_{k}_{s}"

# 获取作物的类型信息
# ['平旱地', '梯田', '山坡地']允许种植的作物集合
grain_crops = crop_data[crop_data['作物类型'].str.contains('粮食') & (crop_data['作物名称'] != '水稻')].index

# 水稻集合(水浇地)
rice_crops_index = crop_data[crop_data['作物名称'] == '水稻'].index[0]
# 水浇地第一季允许种植的蔬菜(水浇地和普通大棚）/ 智慧大棚两季允许种植的蔬菜
allowed_first_season_crops = crop_data[(crop_data['作物类型'].str.contains('蔬菜')) & (~crop_data['作物名称'].isin(['大白菜', '白萝卜', '红萝卜']))].index
# 水浇地第二季允许种植的蔬菜
allowed_second_season_crops = crop_data[crop_data['作物名称'].isin(['大白菜', '白萝卜', '红萝卜'])].index

# 普通大棚第二季（食用菌）
mushroom_crops = crop_data[crop_data['作物类型'].str.contains('食用菌')].index

# 各种地块的约束
for t in years:
    for k in lands:
        # 获取地块类型
        land_type = land_data.loc[k, '地块类型']
        # 获取地块的最大种植面积
        max_area = land_data.loc[k, '种植面积/亩']

        if land_type in ['平旱地', '梯田', '山坡地']:
            # 这些类型地块每年只能种植一季
            for i in crops:
                model += A[(i, t, k, 2)] == 0, f"SingleSeason_{i}_{t}_{k}_{s}"
                model += x[(i, t, k, 2)] == 0, f"SingleSeason_Binary_{i}_{t}_{k}_{s}"
                # 仅允许种植粮食类作物（水稻除外）
                if i not in grain_crops:
                    model += A[(i, t, k, 1)] == 0, f"GrainField_Area_{i}_{t}_{k}"
                    model += x[(i, t, k, 1)] == 0, f"GrainField_Binary_{i}_{t}_{k}"
            # 总种植面积等于地块面积
            for s in seasons:
                total_area = lpSum(A[(i, t, k, s)] for i in crops)
                model += total_area == max_area * (s != 2), f"MaxArea_{t}_{k}_{s}"


        elif land_type == '水浇地':
            # 第一季种植限制：只能种水稻或允许的蔬菜
            for i in crops:
                if i != rice_crops_index and i not in allowed_first_season_crops:
                    model += A[(i, t, k, 1)] == 0, f"WaterField_FirstSeason_Area_{i}_{t}_{k}"
                    model += x[(i, t, k, 1)] == 0, f"WaterField_FirstSeason_Binary_{i}_{t}_{k}"

            # 如果第一季种植了水稻，第二季不能种植任何作物
            model += lpSum(x[(rice_crops_index, t, k, 1)]) + lpSum(x[(i, t, k, 2)] for i in crops) <= 1, f"WaterField_Rice_SecondSeason_{t}_{k}"

            # 如果第一季没有种水稻，第二季只能种大白菜、白萝卜或红萝卜中的一种
            for i in crops:
                if i not in allowed_second_season_crops:
                    model += A[(i, t, k, 2)] == 0, f"WaterField_SecondSeason_Area_{i}_{t}_{k}"
                    model += x[(i, t, k, 2)] == 0, f"WaterField_SecondSeason_Binary_{i}_{t}_{k}"

            # 定义一个新的二进制变量 z_rice，用于表示第一季是否种植了水稻
            z_rice = LpVariable(f"z_rice_{t}_{k}", cat='Binary')
            # 如果第一季种植了水稻，z_rice = 1；否则，z_rice = 0
            model += z_rice == lpSum(x[(rice_crops_index, t, k, 1)]), f"RicePlantingIndicator_{t}_{k}"
            # 总种植面积等于地块面积
            for s in seasons:
                total_area = lpSum(A[(i, t, k, s)] for i in crops)
                if s == 1:
                    model += total_area == max_area, f"MaxArea_{t}_{k}_{s}"
                if s == 2:
                    model += total_area <= max_area * (1 - z_rice), f"ZeroAreaIfRicePlanted_{t}_{k}_{s}"


        elif land_type == '普通大棚':
            # 普通大棚可种蔬菜约束
            for i in crops:
                if i not in allowed_first_season_crops:
                    model += A[(i, t, k, 1)] == 0, f"Greenhouse_FirstSeason_Area_{i}_{t}_{k}"
                    model += x[(i, t, k, 1)] == 0, f"Greenhouse_FirstSeason_Binary_{i}_{t}_{k}"

            # 第二季只能种植食用菌
            for i in crops:
                if i not in mushroom_crops:
                    model += A[(i, t, k, 2)] == 0, f"Greenhouse_SecondSeason_Area_{i}_{t}_{k}"
                    model += x[(i, t, k, 2)] == 0, f"Greenhouse_SecondSeason_Binary_{i}_{t}_{k}"

            # 总种植面积等于地块面积
            for s in seasons:
                total_area = lpSum(A[(i, t, k, s)] for i in crops)
                model += total_area == max_area, f"MaxArea_{t}_{k}_{s}"


        elif land_type == '智慧大棚':
            # 每年两季都可种植蔬菜，但不能是大白菜、白萝卜和红萝卜
            for s in seasons:
                for i in crops:
                    if i not in allowed_first_season_crops:
                        model += A[(i, t, k, s)] == 0, f"SmartGreenhouse_Season_Area_{i}_{t}_{k}_{s}"
                        model += x[(i, t, k, s)] == 0, f"SmartGreenhouse_Season_Binary_{i}_{t}_{k}_{s}"

                # 总种植面积等于地块面积
                total_area = lpSum(A[(i, t, k, s)] for i in crops)
                model += total_area == max_area, f"MaxArea_{t}_{k}_{s}"


# 不允许连续种植相同作物（重茬）
for t in range(2024, 2030):  # 只需检查到 2029 年
    for k in lands:
        for i in crops:
            for s in seasons:
                model += x[(i, t, k, s)] + x[(i, t+1, k, s)] <= 1, f"NoContinuous_{i}_{t}_{k}_{s}"

# 每个地块三年内至少种植一次豆类作物
beans = crop_data[crop_data['作物名称'].str.contains('豆')].index
for t in range(2024, 2028):  # 只需检查到2027年，因为检查三年窗口
    for k in lands:
        model += lpSum(x[(i, t+j, k, 1)] for i in beans for j in range(3)) >= 1, f"PlantBeans_{t}_{k}"

# 求解模型
solver = PULP_CBC_CMD(msg=True,threads=5, timeLimit=60)
model.solve(solver)

# 输出结果
print(f"状态: {LpStatus[model.status]}")
print(f"最优目标函数值: {model.objective.value()}")

# 创建一个空的列表来存储输出结果
output = []

# 输出种植决策
for i in crops:
    for t in years:
        for k in lands:
            for s in seasons:
                if A[(i, t, k, s)].varValue > 0:
                    # 获取对应的地块名称和作物名称
                    land_name = land_data.loc[k, '种植地块']  # 获取地块名称
                    crop_name = crop_data.loc[i, '作物名称']  # 获取作物名称
                    # 添加结果到输出列表
                    output.append([t, s, land_name, crop_name, A[(i, t, k, s)].varValue])

# 将输出结果转换为 DataFrame
output_df = pd.DataFrame(output, columns=['年份', '季次', '地块名称', '作物名称', '种植面积(亩)'])

# # 将结果写入 CSV 文件
# output_df.to_csv('种植决策结果.csv', index=False)
# print("种植决策结果已成功导出到 '种植决策结果.csv' 文件。")

# 获取所有出现的作物名称，并按字母顺序排序
all_crops_sorted = ans.columns[2:]

# 按年份和季次分组种植决策数据
grouped_data = output_df.groupby(['年份', '季次'])

# 自定义地块名称的排序函数
def sort_land_names(land_name):
    # 分离地块名称中的字母和数字部分
    letters = ''.join(filter(str.isalpha, land_name))  # 提取字母部分
    numbers = ''.join(filter(str.isdigit, land_name))  # 提取数字部分
    # 将字母部分作为主要排序依据，数字部分作为次要排序依据
    return (letters, int(numbers) if numbers else 0)

# 创建一个新的Excel文件来保存整理后的数据
output_path = '种植决策结果.xlsx'

# 使用ExcelWriter保存数据
with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
    # 遍历每年和每季的组合，创建相应的表格
    for (year, season), data in grouped_data:
        # 透视数据，行是地块名称，列是作物名称，值是种植面积
        table = data.pivot_table(index='地块名称', columns='作物名称', values='种植面积(亩)', fill_value=0)

        # 确保所有列（作物）都按照排序后的顺序列出，即使某些列在某些季次中没有数据
        table = table.reindex(columns=all_crops_sorted, fill_value=0)

        # 根据地块名称的自定义排序函数进行排序
        table = table.sort_index(key=lambda x: x.map(sort_land_names))

        # 创建一个工作表名称，例如 "2024_Season1"
        sheet_name = f'{year}_Season{season}'

        # 将表格写入Excel文件
        table.to_excel(writer, sheet_name=sheet_name)

print("种植决策结果保存成功。")